<!-- Basic -->
<meta charset="utf-8">
<title>Abang Shop</title>
<meta name="keywords" content="HTML5 Template" />
<meta name="description" content="Abang Shop">
<meta name="author" content="etheme.com">
<link rel="shortcut icon" href="favicon.ico">
<!-- Mobile Specific Metas -->
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- External Plugins CSS -->
<link rel="stylesheet" href="<?php echo base_url(); ?>main_assets/landing_page_asset/assets/external/slick/slick.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>main_assets/landing_page_asset/assets/external/slick/slick-theme.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>main_assets/landing_page_asset/assets/external/magnific-popup/magnific-popup.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>main_assets/landing_page_asset/assets/external/bootstrap-select/bootstrap-select.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>main_assets/landing_page_asset/assets/external/nouislider/nouislider.css">
<!-- SLIDER REVOLUTION 4.x CSS SETTINGS -->
<link rel="stylesheet" href="<?php echo base_url(); ?>main_assets/landing_page_asset/assets/external/rs-plugin/css/settings.css" media="screen" />
<!-- Custom CSS -->
<link rel="stylesheet" href="<?php echo base_url(); ?>main_assets/landing_page_asset/assets/css/style.css">
<!-- Icon Fonts  -->
<link rel="stylesheet" href="<?php echo base_url(); ?>main_assets/landing_page_asset/assets/font/style.css">
<!-- Head Libs -->	
<style>
    .row-contact_us{
        border-bottom: 1px solid #e5e5e5;
    }
    .row-bottom-new{
        font-weight: 400;
    }

    .img-hover-zoom {       
        overflow: hidden; /* [1.2] Hide the overflowing of child elements */
    }

    /* [2] Transition property for smooth transformation of images */
    .img-hover-zoom img {
        transition: transform .5s ease;
    }

    /* [3] Finally, transforming the image when container gets hovered */
    .img-hover-zoom:hover img {
        transform: scale(1.1);
    }
</style>
<!-- Modernizr -->
<script src="<?php echo base_url(); ?>main_assets/landing_page_asset/assets/external/modernizr/modernizr.js"></script>

<!-- brands-carousel -->
<div class="content section-indent-bottom">
    <div class="container">
        <div class="row">
            <div class="brands-carousel">
                <div><a href="#"><img src="images/custom/brand-01.png" alt=""></a></div>
                <div><a href="#"><img src="images/custom/brand-02.png" alt=""></a></div>
                <div><a href="#"><img src="images/custom/brand-03.png" alt=""></a></div>
                <div><a href="#"><img src="images/custom/brand-04.png" alt=""></a></div>
                <div><a href="#"><img src="images/custom/brand-05.png" alt=""></a></div>
                <div><a href="#"><img src="images/custom/brand-06.png" alt=""></a></div>
                <div><a href="#"><img src="images/custom/brand-07.png" alt=""></a></div>
                <div><a href="#"><img src="images/custom/brand-08.png" alt=""></a></div>
                <div><a href="#"><img src="images/custom/brand-09.png" alt=""></a></div>
                <div><a href="#"><img src="images/custom/brand-10.png" alt=""></a></div>
                <div><a href="#"><img src="images/custom/brand-01.png" alt=""></a></div>
                <div><a href="#"><img src="images/custom/brand-02.png" alt=""></a></div>
                <div><a href="#"><img src="images/custom/brand-03.png" alt=""></a></div>
                <div><a href="#"><img src="images/custom/brand-04.png" alt=""></a></div>
                <div><a href="#"><img src="images/custom/brand-05.png" alt=""></a></div>
                <div><a href="#"><img src="images/custom/brand-06.png" alt=""></a></div>
                <div><a href="#"><img src="images/custom/brand-07.png" alt=""></a></div>
                <div><a href="#"><img src="images/custom/brand-08.png" alt=""></a></div>
                <div><a href="#"><img src="images/custom/brand-09.png" alt=""></a></div>
                <div><a href="#"><img src="images/custom/brand-10.png" alt=""></a></div>
            </div>
        </div>
    </div>
</div> 
<!-- /brands-carousel -->